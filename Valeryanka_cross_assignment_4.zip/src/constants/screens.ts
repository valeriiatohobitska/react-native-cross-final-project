export const SCREENS = {
  DRAWER_HOME: 'DrawerHome',
  DRAWER_HELP: 'DrawerHelp',
  DRAWER_CONTACTS: 'DrawerContacts',
  DRAWER_LOGOUT: 'DrawerLogout',
  TAB_MENU: 'TabMenu',
  TAB_CART: 'TabCart',
  TAB_HISTORY: 'TabHistory',
  TAB_PROFILE: 'TabProfile',
  HOME: 'Home',
  SEARCH: 'Search',
  PRODUCT_DETAILS: 'ProductDetails',
  CHECKOUT: 'Checkout',
} as const;
